import React from 'react';
import { StyleSheet, Text, View, ScrollView, StatusBar, Image } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';

const Home = () => (
  <SafeAreaView style={styles.fundo}>
    <ScrollView contentContainerStyle={styles.espacamento}>
      <View style={styles.cabecalho}>
        <Text style={styles.nome}>MATHEUS{"\n"}HIGA</Text>
        <Image 
          source={require('./assets/aura.jpg')} 
          style={styles.foto} 
        />
      </View>
      
      <View style={styles.bloco}>
        <Text style={styles.texto}>
          o melhor desenvolvedor que voce vai ter a oportunidade de conhecer, faz sites e programas como nunca visto antes!
        </Text>
      </View>

      <View style={styles.linha}>
        <Feather name="mail" size={18} color="#000" />
        <Text style={styles.link}>matheus.higa@email.com</Text>
      </View>
    </ScrollView>
  </SafeAreaView>
);

const ExperienciaPro = () => (
  <SafeAreaView style={styles.fundo}>
    <ScrollView contentContainerStyle={styles.espacamento}>
      <Text style={styles.nome}>Experiencia Profissional</Text>
      {[
        { cargo: 'galã profissional'},
        { cargo: 'degustador de lanche (dos outros)'},
        { cargo: 'crítico de sites'}
      ].map((item, index) => (
        <View key={index} style={styles.itemlista}>
          <Text style={styles.titulolista}>{item.cargo}</Text>
        </View>
      ))}
    </ScrollView>
  </SafeAreaView>
);

const ExperienciaAcad = () => (
  <SafeAreaView style={styles.fundo}>
    <ScrollView contentContainerStyle={styles.espacamento}>
      <Text style={styles.nome}>estudos</Text>
      <View style={styles.bloco}>
        <Text style={styles.titulolista}>formado em ctrl + c e ctrl + v</Text>
        <Text style={styles.subtitulo}>(especialista em ia)</Text>
      </View>
    </ScrollView>
  </SafeAreaView>
);

const Hab = () => (
  <SafeAreaView style={styles.fundo}>
    <View style={styles.espacamento}>
      <Text style={styles.nome}>poderes</Text>
      <View style={styles.grade}>
        {['tiktoker', 'gostosao', 'guarda segredo', 'programador', 'mestre da ia'].map(s => (
          <View key={s} style={styles.etiqueta}>
            <Text style={styles.textoetiqueta}>{s}</Text>
          </View>
        ))}
      </View>
    </View>
  </SafeAreaView>
);

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <SafeAreaProvider>
      <NavigationContainer>
        <StatusBar barStyle="dark-content" />
        <Tab.Navigator screenOptions={{ headerShown: false }}>
          <Tab.Screen name="dados" component={Home} />
          <Tab.Screen name="experiencia profissional" component={ExperienciaPro} />
          <Tab.Screen name="experiencia academica" component={ExperienciaAcad} />
          <Tab.Screen name="habilidades" component={Hab} />
        </Tab.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  fundo: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  espacamento: {
    padding: 25,
  },
  cabecalho: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 40,
  },
  nome: {
    fontSize: 42,
    fontWeight: '900',
    color: '#000',
    lineHeight: 40,
  },
  foto: {
    width: 90,
    height: 90,
    borderWidth: 3,
    borderColor: '#000',
  },
  bloco: {
    backgroundColor: '#fff',
    borderWidth: 3,
    borderColor: '#000',
    padding: 20,
    marginBottom: 30,
  },
  texto: {
    fontSize: 18,
    color: '#333',
  },
  linha: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  link: {
    fontSize: 16,
    textDecorationLine: 'underline',
  },
  itemlista: {
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    paddingVertical: 20,
  },
  titulolista: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
  },
  subtitulo: {
    fontSize: 16,
    color: '#666',
  },
  grade: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginTop: 20,
  },
  etiqueta: {
    borderWidth: 2,
    borderColor: '#000',
    paddingHorizontal: 15,
    paddingVertical: 8,
    backgroundColor: '#fff',
  },
  textoetiqueta: {
    fontWeight: 'bold',
    fontSize: 14,
  },
});